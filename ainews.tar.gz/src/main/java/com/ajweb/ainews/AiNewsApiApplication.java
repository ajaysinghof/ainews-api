package com.ajweb.ainews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiNewsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiNewsApiApplication.class, args);
	}

}
